package com.example.meetingcalendarassistant.controller;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.meetingcalendarassistant.service.CalendarService;

@RestController
@RequestMapping("/api/calendar")
public class CalendarController {
    @Autowired
    private CalendarService calendarService;

    @PostMapping("/book")
    public ResponseEntity<String> bookMeeting(
            @RequestParam Long ownerId,
            @RequestParam String startTime,
            @RequestParam String endTime,
            @RequestParam List<Long> participantIds) {
        
        LocalDateTime start = LocalDateTime.parse(startTime);
        LocalDateTime end = LocalDateTime.parse(endTime);
        
        boolean success = calendarService.bookMeeting(ownerId, start, end, participantIds);
        return success ? ResponseEntity.ok("Meeting booked successfully") 
                       : ResponseEntity.status(HttpStatus.CONFLICT).body("Conflicts detected");
    }

    @GetMapping("/free-slots")
    public List<LocalDateTime[]> getFreeSlots(
            @RequestParam Long empId1,
            @RequestParam Long empId2,
            @RequestParam long durationMinutes) {
        
        return calendarService.findFreeSlots(empId1, empId2, Duration.ofMinutes(durationMinutes));
    }
}
