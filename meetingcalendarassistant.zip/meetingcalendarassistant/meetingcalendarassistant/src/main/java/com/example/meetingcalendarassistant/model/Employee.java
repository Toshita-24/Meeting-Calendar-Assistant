package com.example.meetingcalendarassistant.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Employee {
    @Id
    private Long id;
    private String name;
    @OneToMany(mappedBy = "owner")
    private List<Meeting> meetings;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}