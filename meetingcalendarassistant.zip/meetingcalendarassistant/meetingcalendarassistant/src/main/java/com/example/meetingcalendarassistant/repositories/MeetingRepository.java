package com.example.meetingcalendarassistant.repositories;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.meetingcalendarassistant.model.Employee;
import com.example.meetingcalendarassistant.model.Meeting;

@Repository
public interface MeetingRepository extends JpaRepository<Meeting, Long> {
    List<Meeting> findByOwnerAndStartTimeBetween(Employee owner, LocalDateTime start, LocalDateTime end);

	List<Meeting> findByOwner(Employee emp1);
    
}