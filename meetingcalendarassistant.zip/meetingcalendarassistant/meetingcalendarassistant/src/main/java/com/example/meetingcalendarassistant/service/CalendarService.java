package com.example.meetingcalendarassistant.service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.meetingcalendarassistant.model.Employee;
import com.example.meetingcalendarassistant.model.Meeting;
import com.example.meetingcalendarassistant.repositories.EmployeeRepository;
import com.example.meetingcalendarassistant.repositories.MeetingRepository;

@Service
public class CalendarService {
    @Autowired
    private MeetingRepository meetingRepo;
    @Autowired
    private EmployeeRepository employeeRepo;

    public boolean bookMeeting(Long ownerId, LocalDateTime startTime, LocalDateTime endTime, List<Long> participantIds) {
        Employee owner = employeeRepo.findById(ownerId).orElseThrow(() -> new RuntimeException("Owner not found"));
        List<Employee> participants = employeeRepo.findAllById(participantIds);

        if (checkConflicts(owner, startTime, endTime, participants)) {
            Meeting meeting = new Meeting();
            meeting.setOwner(owner);
            meeting.setStartTime(startTime);
            meeting.setEndTime(endTime);
            meeting.setParticipants(participants);
            meetingRepo.save(meeting);
            return true;
        }
        return false;
    }

    private boolean checkConflicts(Employee owner, LocalDateTime startTime, LocalDateTime endTime, List<Employee> participants) {
        // Check for conflicts with the owner's schedule
        List<Meeting> ownerMeetings = meetingRepo.findByOwnerAndStartTimeBetween(owner, startTime, endTime);
        if (!ownerMeetings.isEmpty()) return false;

        // Check for conflicts with participants
        for (Employee participant : participants) {
            List<Meeting> participantMeetings = meetingRepo.findByOwnerAndStartTimeBetween(participant, startTime, endTime);
            if (!participantMeetings.isEmpty()) return false;
        }
        return true;
    }

    public List<LocalDateTime[]> findFreeSlots(Long empId1, Long empId2, Duration duration) {
        Employee emp1 = employeeRepo.findById(empId1).orElseThrow(() -> new RuntimeException("Employee 1 not found"));
        Employee emp2 = employeeRepo.findById(empId2).orElseThrow(() -> new RuntimeException("Employee 2 not found"));

        // Fetch meetings for each employee
        List<Meeting> emp1Meetings = meetingRepo.findByOwner(emp1);
        List<Meeting> emp2Meetings = meetingRepo.findByOwner(emp2);

        // Calculate free slots based on both employees' schedules
        return calculateFreeSlots(emp1Meetings, emp2Meetings, duration);
    }
    
    private List<LocalDateTime[]> calculateFreeSlots(List<Meeting> emp1Meetings, List<Meeting> emp2Meetings, Duration duration) {
        // Logic to calculate overlapping free slots of specified duration
        return new ArrayList<>();
    }
}
