package com.example.meetingcalendarassistant.testing;

import static org.junit.Assert.assertTrue;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;


import com.example.meetingcalendarassistant.service.CalendarService;

@SpringBootTest
public class CalendarServiceTests {
    @Autowired
    private CalendarService calendarService;

    @Test
    public void testBookMeeting_NoConflicts() {
        Long ownerId = 1L;
        List<Long> participantIds = Arrays.asList(2L, 3L);
        LocalDateTime start = LocalDateTime.of(2024, 11, 4, 10, 0);
        LocalDateTime end = LocalDateTime.of(2024, 11, 4, 10, 30);

        boolean success = calendarService.bookMeeting(ownerId, start, end, participantIds);
        assertTrue(success);
    }
}
