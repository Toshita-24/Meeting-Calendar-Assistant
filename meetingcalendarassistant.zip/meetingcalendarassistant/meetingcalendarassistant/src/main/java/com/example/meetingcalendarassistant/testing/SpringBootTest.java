package com.example.meetingcalendarassistant.testing;

public @interface SpringBootTest {

}
